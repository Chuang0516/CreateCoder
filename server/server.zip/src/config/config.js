module.exports = {
  redisConfig: {
    host: 'localhost',
    port: '6379',
  },
}
